# THE BEST, PRO, BLOOKET CHEAT GUI OUT THERE!
Supported Websites (fixed): (anything).blooket.com‎‎/(anything)
![blooketcheatgui](https://github.com/swagging-post/Blooket-Cheat-GUI/assets/160811072/7f842fb9-9c94-480b-b594-55850b091fe3)
# READ FOR IMPORTANT INFO! | V2.
A reupload, but currently being fixed of my stolen Blooket Cheats.

<p align="center">Cheats now being managed by SC0TT until further notice.</p>
<p align="center">🚨 IF BEN READS THIS: THIS IS A PARODY GUI, THIS DOESN'T WORK CORRECTLY! 🚨</p>
<h3 align="center"><a href="https://discord.gg/ZDDcsr9SQZ">Support Server | #tickets </a></h2>
<h3 align="center"><a href="#list-of-cheats-1">List Of Cheats</a></h3>

## Star History
<a href="https://star-history.com/#swagging-post/blooket-cheat-gui&Date">
 <picture>
   <source media="(prefers-color-scheme: dark)" srcset="https://api.star-history.com/svg?repos=swagging-post/blooket-cheat-gui&type=Date&theme=dark" />
   <source media="(prefers-color-scheme: light)" srcset="https://api.star-history.com/svg?repos=swagging-post/blooket-cheat-gui&type=Date" />
   <img alt="Star History Chart" src="https://api.star-history.com/svg?repos=swagging-post/blooket-cheat-gui&type=Date" />
 </picture>
</a>

## Information

<details>
  <summary><h3>How to use</h3></summary>
  
  There are 2 good methods to using these scripts:
  1. Copying the main GUI and running it in the inspect element console
  2. Copying the .min.js GUI and using it as a bookmarklet
  
<details>
  <summary>What can I do if JavaScript is blocked?</summary>
  We don't actually know what to do about this or how to fix it, sorry.
</details>
</details>



<details><summary><h3>(script) is not working?</h3></summary>

Make sure you're running it properly (see [How to use](https://github.com/swagging-post/Blooket-Cheeto#how-to-use)), if it still doesn't work and other cheats do, then [make an issue](https://github.com/swagging-post/Blooket-Cheeto/issues)
</details>

<details><summary><h3>Which script should I use to make a bookmarklet?</h3></summary>

You should use the scripts ending in ".min.js", as using the others will have errors due to formatting.
</details>

<details><summary><h3>Can you give me infinite tokens / bypass daily limit / permanently give me blooks / change pack luck?</h3></summary>

No, these are things we would've already done if they were possible, they're managed on the backend of Blooket so we can't modify them
</details>

<details><summary><h3>Can you make hacks for (game)</h3></summary>

No
</details>

<details><summary><h3>Can you make more Battle Royale cheats</h3></summary>

Battle Royale is a gamemode that works almost entirely on the host's end. The only thing we have control over is answering questions.
</details>

<details><summary><h3>What happened to Minesraft2 and 05Konz?</h3></summary>

Minesraft2 was sent a cease and desist from Blooket and 05Konz was perm banned, so I took over since they wouldn't be able to and try to fix the cheats.
</details>

<details>
  <summary><h3>How do I do this on mobile?</h3></summary>
  
  These scripts aren't made for mobile, so we don't really know how to get them to work on it.
  
  <details>
    <summary><h3>What's the Mobile GUI?</h3></summary>
    The mobile GUI is the first GUI Minesraft2 ever made. Some people said it worked on mobile and it's a lot neater for mobile use apparently so we just called it that.
  </details>
</details>



<details><summary><h2>List of Cheats</h2></summary>
<h3>GUIs<h3>
  
* [GUI](cheats/gui/gui.js)
* [GUI Bookmarklet](cheats/gui/gui.min.js)
* [Mobile GUI outdated](cheats/gui/mobileGui.js)
* [Mobile GUI Bookmarklet outdated](cheats/gui/mobileGui.min.js)
### Global:
- Auto Answer
- Highlight Answers
- Subtle Highlight Answers
- Percent Auto Answer
- Auto Answer
- Highlight Answers
- Use any Banner
- Spam Buy Blooks
- Freeze Host
- Live Player Count
- Use Any Blook
- Use Occupied Blooks
- Get 3rd Party Blooks
- Set Custom Blook (IMG URL)
- Change Blook Ingame
- Get Daily Rewards
- Every Answer Correct
- Subtle Highlight Answers
- Remove Name Limit
- Remove Random Name
- Bypass Nickname Filter
- Pin Guesser
- Sell Duplicate Blooks

### Host:
- Host Any Gamemode
- Free Player Slots
- Instant Leaderboard Updates
- Kick All Players

### Voyage:
- Max Levels
- Set Doubloons
- Start Heist
- Swap Doubloons
- Take Doubloons

### Brawl:
- Double Enemy XP
- Half Enemy Speed
- Instant Kill
- Invincibility
- Magnet
- Max Current Abilities
- Next Level
- Remove Obstacles
- Kill Enemies
- Reset Health

### Cafe:
- Max Items
- Remove Customers
- Reset Abilities
- Set Cash
- Stock Food

### Crypto:
- Choice ESP
- Password ESP
- Show Player's Password
- Always Triple
- Always Quintuple
- Always Decuple
- Anti-Hack (Crashes Players)
- Anti-Hack (Freezes Players)
- Auto Guess
- Remove Hack
- Set Crypto
- Set Password
- Screen Flooding
- Steal Player's Crypto

### Factory:
- Choose Blook
- Free Upgrades
- Max Blooks
- Remove Glitches
- Send Glitch
- Set All MegaBot
- Set Cash

### Fishing:
- Frenzy
- Always Frenzy
- Remove Distractions
- Send Distraction
- Set Lure
- Set Weight

### Gold:
- Always Triple
- Always Quintuple
- Always Decuple
- Auto Choose
- Chest ESP
- Remove Lose 25%-50%
- Reset Players Gold
- Set Gold
- Swap Gold
- Reset All Players' Gold

### Kingdom:
- Choice ESP
- Disable Tax Toucan
- Max Stats
- Set Guests
- Skip Guest

### Racing:
- Instant Win
- Set Questions

### Royale:
- Auto Answer (Toggle)
- Auto Answer

### Rush:
- Set Blooks
- Set Defense

### Workshop:
- Remove Distractions
- Send Distraction
- Set Toys
- Set Toys Per Question
- Swap Toys

### Settings:
- Import Settings
- Export Settings
- Defaults
- Background Color
- Category List Color
- Info Color
- Button Color
- Enabled Toggle Color
- Disabled Toggle Color
- Text Color
- Input Color
- Content Color
</details>

